package com.mcs.be.course.exception;

public class ElementNotFound extends Exception {

    public ElementNotFound(String message) {
        super(message);
    }
}
