package com.mcs.be.course.controller.rest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//TODO add correct annotations
public class RestArticleController {

    private static final Logger LOGGER = LogManager.getLogger(RestArticleController.class);


    //TODO inject facade


    //TODO create method that responds to /articles in GET and returning a list of ArticleDto

    //TODO create method that responds to /articles/{id} in GET and returning a ArticleDto

    //TODO create method that responds to /articles/like in PATCH receiving a json like {"id" : 1} and returning a ArticleDto after updating his like value


}
