package com.mcs.be.course.dao;

import com.mcs.be.course.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

import static org.hibernate.jpa.AvailableSettings.PERSISTENCE_UNIT_NAME;

@Repository
public interface ArticleDao extends JpaRepository<Article, Long> {

    default List<Article> searchBy(EntityManager em, String searchBy, String searchValue) {


        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Article> query = cb.createQuery(Article.class);
        Root<Article> root = query.from(Article.class);
        query.select(root);

        final List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.equal(root.get(searchBy), searchValue));
        query.where(cb.and(predicates.toArray(new Predicate[predicates.size()])));

        List<Article> result = em.createQuery(query).getResultList();

        return result;
    }



}
