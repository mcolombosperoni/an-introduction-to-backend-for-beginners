package com.mcs.be.course.productinventory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Product implements Serializable,Comparable<Product> {

    private String code;
    private String name;
    private String description;
    private BigDecimal price;
    private Date expiringDate;

    public Product() {
    }

    public Product(String code, String name, String description, BigDecimal price, Date expiringDate) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.price = price;
        this.expiringDate = expiringDate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(Date expiringDate) {
        this.expiringDate = expiringDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product product = (Product) o;

        return getCode().equals(product.getCode());
    }

    @Override
    public int hashCode() {
        return getCode().hashCode();
    }


    @Override
    public int compareTo(Product o) {
        return Integer.valueOf(getCode()).compareTo(Integer.valueOf(o.getCode()));
    }
}
