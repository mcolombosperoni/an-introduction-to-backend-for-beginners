package com.mcs.be.course.productinventory;

import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;


public class Inventory {

    private static Inventory instance;

    private Set<Product> products = new TreeSet<>();

    private Inventory(){
        Random gen = new Random();
        int range = 2*365; //5 years
        DateTime randomDate = DateTime.now().plusDays((gen.nextInt(range)));
        products.add(new Product("100","Product Name 1","description product 1", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("101","Product Name 2","description product 2", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("102","Product Name 3","description product 3", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("103","Product Name 4","description product 4", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("104","Product Name 5","description product 5", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("105","Product Name 6","description product 6", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("106","Product Name 7","description product 7", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("107","Product Name 8","description product 8", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("108","Product Name 9","description product 9", BigDecimal.valueOf(100), randomDate.toDate()));
        products.add(new Product("109","Product Name 10","description product 10", BigDecimal.valueOf(100), randomDate.toDate()));
    }

    public Set<Product> getProducts() {
        return products;
    }

    public void addProduct(Product p) {
        products.add(p);
    }

    public Product getProductByCode(String code) {
        return products.parallelStream().filter(p->p.getCode().equals(code)).findFirst().orElse(null);
    }

    public static Inventory getInstance() {
        if(instance == null){
            instance = new Inventory();
        }
        return instance;
    }


}
