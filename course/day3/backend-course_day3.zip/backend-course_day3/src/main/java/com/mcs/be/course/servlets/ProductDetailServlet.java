package com.mcs.be.course.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(
        name = "ProductDetailServlet",
        urlPatterns = {"/product-detail"}
)
public class ProductDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO get id parameter from the request and use it to retrieve product to send to detail jsp
        // TODO handle also the case in which the product is not found and redirect the request to product list servlet
   }

}
