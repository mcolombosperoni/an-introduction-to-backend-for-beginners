package com.mcs.day2.productinventory.enums;

public enum ProductType {

    DVD, TV;
}
