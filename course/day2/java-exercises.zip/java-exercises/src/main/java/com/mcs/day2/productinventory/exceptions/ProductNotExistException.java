package com.mcs.day2.productinventory.exceptions;

public class ProductNotExistException extends Exception {
}
