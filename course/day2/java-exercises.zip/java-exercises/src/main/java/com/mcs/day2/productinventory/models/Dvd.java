package com.mcs.day2.productinventory.models;

import java.math.BigDecimal;

public class Dvd extends AbstractProduct {

    private String title;
    private Integer duration;


    public Dvd(String code, Integer quantity, BigDecimal price, String title, Integer duration) {
        super(code, quantity, price);
        this.title = title;
        this.duration = duration;
    }

}
