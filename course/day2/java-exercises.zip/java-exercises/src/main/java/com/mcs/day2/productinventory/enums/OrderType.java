package com.mcs.day2.productinventory.enums;

public enum OrderType {
    CUSTOM, NATURAL
}
