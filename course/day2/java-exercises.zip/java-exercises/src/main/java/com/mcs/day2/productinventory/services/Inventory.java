package com.mcs.day2.productinventory.services;

import com.mcs.day2.productinventory.enums.OrderType;
import com.mcs.day2.productinventory.enums.ProductType;
import com.mcs.day2.productinventory.models.AbstractProduct;

public interface Inventory {
    Iterable<AbstractProduct> getProducts();

    Integer countProducts();

    void addProduct(AbstractProduct product);

    void removeProduct(AbstractProduct product);

    void addProducts(Iterable<AbstractProduct> products);

    void removeProducts(Iterable<AbstractProduct> products);

    Boolean containsProduct(String code);

    AbstractProduct retrieveProduct(String code);

    Iterable<AbstractProduct> sortBy(OrderType orderType);

    Iterable<AbstractProduct> filterBy(ProductType productType);
}
