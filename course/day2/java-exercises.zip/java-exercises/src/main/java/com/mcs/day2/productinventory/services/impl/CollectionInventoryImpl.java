package com.mcs.day2.productinventory.services.impl;

import com.mcs.day2.productinventory.enums.OrderType;
import com.mcs.day2.productinventory.enums.ProductType;
import com.mcs.day2.productinventory.models.AbstractProduct;
import com.mcs.day2.productinventory.services.Inventory;

import java.util.Collection;

public class CollectionInventoryImpl implements Inventory {

    private Collection<AbstractProduct> inventory;

    public Iterable<AbstractProduct> getProducts() {
        //TODO
        return null;
    }

    public Integer countProducts() {
        //TODO
        return null;
    }

    public void addProduct(AbstractProduct product) {
        //TODO
    }

    public void removeProduct(AbstractProduct product) {
        //TODO
    }

    public void addProducts(Iterable<AbstractProduct> products) {
        //TODO
    }

    public void removeProducts(Iterable<AbstractProduct> products) {
        //TODO
    }

    public Boolean containsProduct(String code) {
        //TODO
        return null;
    }

    public AbstractProduct retrieveProduct(String code) {
        //TODO
        return null;
    }

    @Override
    public Iterable<AbstractProduct> sortBy(OrderType orderType) {
        //TODO
        return null;
    }

    @Override
    public Iterable<AbstractProduct> filterBy(ProductType productType) {
        //TODO
        return null;
    }
}
