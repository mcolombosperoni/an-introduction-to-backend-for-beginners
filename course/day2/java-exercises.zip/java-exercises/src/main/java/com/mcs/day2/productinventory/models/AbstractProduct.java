package com.mcs.day2.productinventory.models;

import java.math.BigDecimal;

public abstract class AbstractProduct {

    private String code;

    private Integer quantity;

    private BigDecimal price;

    public AbstractProduct(String code, Integer quantity, BigDecimal price) {
        this.code = code;
        this.quantity = quantity;
        this.price = price;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

}
