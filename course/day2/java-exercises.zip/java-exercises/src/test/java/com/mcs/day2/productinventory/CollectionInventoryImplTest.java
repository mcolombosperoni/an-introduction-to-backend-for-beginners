package com.mcs.day2.productinventory;

import com.mcs.day2.productinventory.enums.OrderType;
import com.mcs.day2.productinventory.enums.ProductType;
import com.mcs.day2.productinventory.exceptions.ProductNotExistException;
import com.mcs.day2.productinventory.models.AbstractProduct;
import com.mcs.day2.productinventory.models.Dvd;
import com.mcs.day2.productinventory.models.Tv;
import com.mcs.day2.productinventory.services.Inventory;
import com.mcs.day2.productinventory.services.impl.CollectionInventoryImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class CollectionInventoryImplTest {

    private Inventory inventory = null;

    private final Tv productA = new Tv("1000", 1, new BigDecimal(300.23), "Dvd A", 32);
    private final Dvd newProduct = new Dvd("9999", 1, new BigDecimal(100.00), "New Dvd", 200);


    @Before
    public void doBeforeEachTest(){
        inventory = new CollectionInventoryImpl();
        inventory.addProduct(new Tv("1000", 1, new BigDecimal(300.23), "Dvd A", 32));
        inventory.addProduct(new Tv("1010",9, new BigDecimal(350.12), "", 32));
        inventory.addProduct(new Tv("1020", 3, new BigDecimal(150.34), "",23));
        inventory.addProduct(new Tv("100", 7, new BigDecimal(700.56), "",50));
        inventory.addProduct(new Dvd("110", 10, new BigDecimal(34.11), "",126));
        inventory.addProduct(new Dvd("1012", 21, new BigDecimal(11.78), "", 137));
        inventory.addProduct(new Tv("1111", 13, new BigDecimal(999.99), "", 55));
        inventory.addProduct(new Dvd("122", 10, new BigDecimal(9.31), "",170));
        inventory.addProduct(new Tv("1221", 100, new BigDecimal(1500.00), "",65));
        inventory.addProduct(new Dvd("1313", 35, new BigDecimal(25.96), "",110));
        inventory.addProduct(new Tv("11", 5, new BigDecimal(333.69), "",32));
        inventory.addProduct(new Dvd("10", 6, new BigDecimal(90.04), "",150));
    }

    @Test
    public void testCountProducts() {
        //when
        Integer result = inventory.countProducts();
        //then
        Assert.assertTrue(result > 0);
    }

    @Test
    public void testContainsProductWithExistentCode() {
        //given
        String productCode="1000";
        //when
        Boolean result = inventory.containsProduct(productCode);
        //then
        Assert.assertTrue(result);
    }

    @Test
    public void testContainsProductWithNotExistentCode() {
        //given
        String productCode="9999";
        //when
        Boolean result = inventory.containsProduct(productCode);
        //then
        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }

    @Test
    public void testRetrieveProduct() {
        //given
        String productCode="1313";
        //when
        Dvd result = (Dvd)inventory.retrieveProduct(productCode);
        //then
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getCode(),productCode);
    }

    @Test
    public void testAddingNewProduct() {
        //when
        Integer beforeAdding = inventory.countProducts();
        inventory.addProduct(newProduct);
        Integer afterAdding = inventory.countProducts();
        //then
        Assert.assertTrue(beforeAdding < afterAdding);
    }

    @Test
    public void testAddingExistentProduct() {
        //when
        Integer beforeAdding = inventory.countProducts();
        inventory.addProduct(productA);
        Integer afterAdding = inventory.countProducts();
        //then
        Assert.assertTrue(beforeAdding.equals(afterAdding));
    }

    @Test
    public void testRemovingExistentProduct() {
        //when
        Integer beforeAdding = inventory.countProducts();
        inventory.removeProduct(productA);
        Integer afterAdding = inventory.countProducts();
        //then
        Assert.assertTrue(beforeAdding.equals(afterAdding));
    }

    @Test(expected = ProductNotExistException.class)
    public void testRemovingNotExistentProduct() {
        //when
        inventory.removeProduct(newProduct);
    }

    @Test
    public void testSortingNaturalByCode() {
        //Given
        final List<String> expectedOrder = Arrays.asList("10", "11", "100", "110", "122", "1000", "1010", "1012", "1020", "1111", "1221", "1313");

        //when
        Iterable<AbstractProduct> list = inventory.sortBy(OrderType.NATURAL);

        //then
        final List<String> sorted = StreamSupport.stream(list.spliterator(), false)
                        .map(AbstractProduct::getCode)
                        .collect(Collectors.toList());
        Assert.assertTrue(sorted.equals(expectedOrder));
    }

    @Test
    public void testSortingCustomByPrice() {
        //Given
        final List<String> expectedOrder = Arrays.asList("122", "1012", "1313", "110", "10", "1020", "1000", "11", "1010", "100", "1111", "1221");

        //when
        Iterable<AbstractProduct> list = inventory.sortBy(OrderType.CUSTOM);

        //then
        final List<String> sorted = StreamSupport.stream(list.spliterator(), false)
                .map(AbstractProduct::getCode)
                .collect(Collectors.toList());
        Assert.assertTrue(sorted.equals(expectedOrder));

    }

    @Test
    public void testFilteringByClass() {
        Collection<AbstractProduct> dvdExpectedList = new ArrayList<>(5);
        Collections.addAll(dvdExpectedList,new Dvd("110", 10, new BigDecimal(34.11), "",126),
        new Dvd("1012", 21, new BigDecimal(11.78), "", 137),
        new Dvd("122", 10, new BigDecimal(9.31), "",170),
        new Dvd("1313", 35, new BigDecimal(25.96), "",110),
        new Dvd("10", 6, new BigDecimal(90.04), "",150));

        Iterable<AbstractProduct> list = inventory.filterBy(ProductType.DVD);

        Assert.assertEquals(dvdExpectedList.size(),((Collection<AbstractProduct>) list).size());
        list.forEach(dvd -> Assert.assertTrue(dvdExpectedList.contains(dvd)));

    }


}