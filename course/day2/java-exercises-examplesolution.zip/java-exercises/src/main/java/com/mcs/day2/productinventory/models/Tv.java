package com.mcs.day2.productinventory.models;

import java.math.BigDecimal;

public class Tv extends AbstractProduct {

    private String model;
    private Integer wide;


    public Tv(String code, Integer quantity, BigDecimal price, String model, Integer wide) {
        super(code, quantity, price);
        this.model = model;
        this.wide = wide;
    }

}
