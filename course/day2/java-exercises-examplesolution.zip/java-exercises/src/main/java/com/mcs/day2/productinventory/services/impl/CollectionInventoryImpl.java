package com.mcs.day2.productinventory.services.impl;

import com.mcs.day2.productinventory.enums.OrderType;
import com.mcs.day2.productinventory.enums.ProductType;
import com.mcs.day2.productinventory.exceptions.ProductNotExistException;
import com.mcs.day2.productinventory.models.AbstractProduct;
import com.mcs.day2.productinventory.models.Dvd;
import com.mcs.day2.productinventory.models.Tv;
import com.mcs.day2.productinventory.services.Inventory;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class CollectionInventoryImpl implements Inventory {

    private Collection<AbstractProduct> inventory;

    public CollectionInventoryImpl() {
        inventory = new TreeSet<>();
    }

    public Iterable<AbstractProduct> getProducts() {
        return inventory;
    }

    public Integer countProducts() {
        return inventory.size();
    }

    public void addProduct(AbstractProduct product) {
        if(inventory.contains(product)) {
            product.setQuantity(product.getQuantity() + 1);
        } else {
            inventory.add(product);
        }
    }

    public void removeProduct(AbstractProduct product) throws ProductNotExistException {
        if(inventory.contains(product)) {
            product.setQuantity(product.getQuantity() - 1);
        } else {
            throw new ProductNotExistException();
        }
    }

    public void addProducts(Iterable<AbstractProduct> products) {
        for (AbstractProduct p: products) {
            this.addProduct(p);
        }
    }

    public void removeProducts(Iterable<AbstractProduct> products) throws ProductNotExistException {
        for (AbstractProduct p: products) {
            this.removeProduct(p);
        }
    }

    public Boolean containsProduct(String code) {
        for (AbstractProduct p: inventory) {
            if (p.getCode().equals(code)){
                return true;
            }
        }
        return false;
    }

    public AbstractProduct retrieveProduct(String code) {
        return inventory.parallelStream().filter(p -> p.getCode().equals(code)).findFirst().get();
    }

    @Override
    public Iterable<AbstractProduct> sortBy(OrderType orderType) {
        Iterable<AbstractProduct> result;
        switch (orderType) {
            case CUSTOM:
                result = inventory.stream().sorted(Comparator.comparing(AbstractProduct::getPrice)).collect(Collectors.toList());
                break;
            case NATURAL:
                result = inventory;
                break;
            default:
                throw new NotImplementedException();
        }
        return result;
    }

    @Override
    public Iterable<AbstractProduct> filterBy(ProductType productType) {
        Iterable<AbstractProduct> result;
        switch (productType) {
            case DVD:
                result = inventory.stream().filter(Dvd.class::isInstance).collect(Collectors.toSet());
                break;
            case TV:
                result = inventory.stream().filter(Tv.class::isInstance).collect(Collectors.toSet());
                break;
            default:
                throw new NotImplementedException();
        }
        return result;
    }
}
