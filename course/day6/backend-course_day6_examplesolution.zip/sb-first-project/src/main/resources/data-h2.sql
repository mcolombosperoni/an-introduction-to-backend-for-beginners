--base
INSERT INTO PRODUCTS (id, code, name, description, price) VALUES (1, '1000', 'Blue Ray', 'Blue Ray disc', 19.99);
INSERT INTO PRODUCTS (id, code, name, description, price) VALUES (2, '1001', 'Sony', 'Sony 4K HDR', 1499.00);

--dvd
INSERT INTO DVDS (id, title, duration) VALUES (1, 'Captain America Civil War', 130);

--tv
INSERT INTO TELEVISIONS (id, model, wide) VALUES (2, 'Sony XD9003', 55);