package com.mcs.springboot.sbfirstproject.services;

import com.mcs.springboot.sbfirstproject.models.Product;

import java.util.List;

public interface ProductService {
    List<Product> retrieveAllProducts();
}
