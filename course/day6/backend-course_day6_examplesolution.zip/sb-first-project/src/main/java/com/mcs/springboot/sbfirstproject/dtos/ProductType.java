package com.mcs.springboot.sbfirstproject.dtos;

public enum ProductType {

    TV,
    DVD,
    GENERIC

}
