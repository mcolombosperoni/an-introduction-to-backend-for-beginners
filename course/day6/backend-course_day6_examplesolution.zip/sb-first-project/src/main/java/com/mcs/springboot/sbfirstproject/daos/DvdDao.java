package com.mcs.springboot.sbfirstproject.daos;

import com.mcs.springboot.sbfirstproject.models.Dvd;
import com.mcs.springboot.sbfirstproject.models.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DvdDao extends ProductDao<Dvd> {

}
