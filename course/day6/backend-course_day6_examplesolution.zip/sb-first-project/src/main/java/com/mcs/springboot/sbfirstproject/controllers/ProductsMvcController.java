package com.mcs.springboot.sbfirstproject.controllers;

import com.mcs.springboot.sbfirstproject.dtos.ProductDto;
import com.mcs.springboot.sbfirstproject.facades.ProductFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/mvc/products")
public class ProductsMvcController {

    @Autowired
    ProductFacade productFacade;

    @GetMapping()
    public ModelAndView getAllProducts() {

        List<ProductDto> products = productFacade.retrieveAllProducts();
        ModelAndView mav = new ModelAndView("productList");
        mav.addObject("products", products);

        return mav;
    }

}
