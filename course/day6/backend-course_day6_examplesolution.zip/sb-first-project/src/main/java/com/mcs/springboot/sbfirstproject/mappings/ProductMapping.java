package com.mcs.springboot.sbfirstproject.mappings;

import com.mcs.springboot.sbfirstproject.dtos.ProductDto;
import com.mcs.springboot.sbfirstproject.dtos.ProductType;
import com.mcs.springboot.sbfirstproject.models.Dvd;
import com.mcs.springboot.sbfirstproject.models.Product;
import com.mcs.springboot.sbfirstproject.models.Tv;
import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class ProductMapping implements OrikaMapperFactoryConfigurer {
    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory.classMap(Product.class, ProductDto.class)
                .byDefault()
                .customize(new CustomMapper<Product, ProductDto>() {
                    @Override
                    public void mapAtoB(Product product, ProductDto productDto, MappingContext context) {
                        super.mapAtoB(product, productDto, context);
                        if(product instanceof Tv) {
                            productDto.setWide(((Tv) product).getWide());
                            productDto.setModel(((Tv) product).getModel());
                            productDto.setType(ProductType.TV);
                        } else if(product instanceof Dvd) {
                            productDto.setDuration((((Dvd) product).getDuration()));
                            productDto.setTitle(((Dvd) product).getTitle());
                            productDto.setType(ProductType.DVD);
                        } else {
                            productDto.setType(ProductType.GENERIC);
                        }
                    }
                })
                .register();

    }
}