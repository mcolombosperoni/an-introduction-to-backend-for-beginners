package com.mcs.springboot.sbfirstproject.daos;

import com.mcs.springboot.sbfirstproject.models.Tv;
import org.springframework.stereotype.Repository;

@Repository
public interface TvDao extends ProductDao<Tv> {

}
