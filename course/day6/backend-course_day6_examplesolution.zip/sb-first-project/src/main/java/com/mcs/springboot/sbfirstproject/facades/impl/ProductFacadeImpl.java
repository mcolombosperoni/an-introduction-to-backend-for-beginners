package com.mcs.springboot.sbfirstproject.facades.impl;

import com.mcs.springboot.sbfirstproject.dtos.ProductDto;
import com.mcs.springboot.sbfirstproject.facades.ProductFacade;
import com.mcs.springboot.sbfirstproject.models.Product;
import com.mcs.springboot.sbfirstproject.services.ProductService;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ProductFacadeImpl implements ProductFacade {

    @Autowired
    private MapperFacade mapperFacade;

    @Autowired
    private ProductService productService;


    @Override
    public List<ProductDto> retrieveAllProducts() {
        final List<Product> entities = productService.retrieveAllProducts();
        final List<ProductDto> dtos = entities.stream().map(a -> mapperFacade.map(a, ProductDto.class))
                .collect(Collectors.toList());
        return dtos;
    }
}
