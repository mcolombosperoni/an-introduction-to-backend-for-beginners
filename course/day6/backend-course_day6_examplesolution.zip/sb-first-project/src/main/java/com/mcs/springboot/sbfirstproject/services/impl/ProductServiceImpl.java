package com.mcs.springboot.sbfirstproject.services.impl;

import com.mcs.springboot.sbfirstproject.daos.DvdDao;
import com.mcs.springboot.sbfirstproject.daos.ProductDao;
import com.mcs.springboot.sbfirstproject.daos.TvDao;
import com.mcs.springboot.sbfirstproject.models.Product;
import com.mcs.springboot.sbfirstproject.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductDao<Product> productDao;

    @Autowired
    DvdDao dvdDao;

    @Autowired
    TvDao tvDao;

    @Override
    public List<Product> retrieveAllProducts() {
        return productDao.findThemAll();
    }

}
