package com.mcs.springboot.sbfirstproject.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TELEVISIONS")
public class Tv extends Product {

    @Column
    protected String model;

    @Column
    protected Integer wide;

    public Tv() {
        super();
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getWide() {
        return wide;
    }

    public void setWide(Integer wide) {
        this.wide = wide;
    }

    @Override
    public String toString() {
        return super.toString() + "Tv{" +
                "model='" + model + '\'' +
                ", wide=" + wide +
                '}';
    }
}
