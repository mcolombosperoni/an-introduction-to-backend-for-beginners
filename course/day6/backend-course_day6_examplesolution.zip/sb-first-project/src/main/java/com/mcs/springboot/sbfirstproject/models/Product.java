package com.mcs.springboot.sbfirstproject.models;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "PRODUCTS")
public class Product extends AbstractProduct {

    @Column
    protected BigDecimal price;

    public Product() {
        super();
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }


    @Override
    public String toString() {
        return super.toString() + "Product{" +
                "price=" + price +
                '}';
    }
}
