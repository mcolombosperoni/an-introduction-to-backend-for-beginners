package com.mcs.springboot.sbfirstproject.controllers;

import com.mcs.springboot.sbfirstproject.dtos.ProductDto;
import com.mcs.springboot.sbfirstproject.facades.ProductFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/rest/products")
public class ProductsRestController {

    @Autowired
    ProductFacade productFacade;

    @GetMapping
    public List<ProductDto> getAllProducts() {
        return productFacade.retrieveAllProducts();
    }

}
