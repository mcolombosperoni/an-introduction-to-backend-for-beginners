package com.mcs.springboot.sbfirstproject.facades;

import com.mcs.springboot.sbfirstproject.dtos.ProductDto;

import java.util.List;

public interface ProductFacade {

    List<ProductDto> retrieveAllProducts();

}
