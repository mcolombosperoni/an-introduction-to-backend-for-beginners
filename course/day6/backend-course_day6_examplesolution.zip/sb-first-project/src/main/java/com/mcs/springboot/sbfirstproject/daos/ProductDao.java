package com.mcs.springboot.sbfirstproject.daos;

import com.mcs.springboot.sbfirstproject.models.Product;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDao<T extends Product> extends BaseProductDao<Product>{

}
