package com.mcs.be.course.services;

import java.util.Set;

public interface InventoryService {
    Set<Product> getProducts();

    Product getProductByCode(String code);
}
