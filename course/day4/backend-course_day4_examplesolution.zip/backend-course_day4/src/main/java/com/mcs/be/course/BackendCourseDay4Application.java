package com.mcs.be.course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCourseDay4Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendCourseDay4Application.class, args);
	}
}
