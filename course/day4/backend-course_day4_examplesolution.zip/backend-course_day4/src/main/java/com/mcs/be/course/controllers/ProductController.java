package com.mcs.be.course.controllers;

import com.mcs.be.course.services.InventoryService;
import com.mcs.be.course.services.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.Set;

@Controller
public class ProductController {

    @Autowired
    private InventoryService inventoryService;

    @GetMapping("/products")
    public ModelAndView products() {

        final Set<Product> products = inventoryService.getProducts();

        ModelAndView mav = new ModelAndView("productList");
        mav.addObject("products", products);


        return mav;
    }

    @GetMapping("/product")
    public ModelAndView product(@RequestParam String code) {

        if(code != null && !code.isEmpty()) {

            final Product product = inventoryService.getProductByCode(code);

            if(null != product) {

                return new ModelAndView("productDetail","product", product);

            }
        }

        return new ModelAndView("redirect:/products");
    }

}
